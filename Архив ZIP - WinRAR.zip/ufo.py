import sys

from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QLabel
from PyQt5.QtCore import Qt, QPoint
from PyQt5.QtGui import QPainter, QColor, QPolygon, QPixmap
from PyQt5.QtCore import Qt


class Example(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.xy = [0, 0]
        self.xy2 = [50, 50]
        self.st = 0
        self.image = QLabel(self)
        self.pixmap = QPixmap('cat.jpg')
        self.image.setPixmap(self.pixmap)

    def initUI(self):
        self.setGeometry(300, 300, 300, 300)
        self.setWindowTitle('UFO - Квадрат')

    def keyPressEvent(self, event):
        print(event.key())
        if event.key() == 16777235:
            self.st = 1
        elif event.key() == 16777234:
            self.st = 2
        elif event.key() == 16777237:
            self.st = 3
        elif event.key() == 16777236:
            self.st = 4
        if self.st == 1:
            if self.xy[1] - 5 < 0:
                self.xy[1] = 250
            else:
                self.xy[1] = self.xy[1] - 5
        elif self.st == 2:
            if self.xy[0] - 5 < 0:
                self.xy[0] = 250
            else:
                self.xy[0] = self.xy[0] - 5
        elif self.st == 4:
            if self.xy[0] + 5 > 250:
                self.xy[0] = 0
            else:
                self.xy[0] = self.xy[0] + 5
        elif self.st == 3:
            if self.xy[1] + 5 > 250:
                self.xy[1] = 0
            else:
                self.xy[1] = self.xy[1] + 5
        self.image.move(*self.xy)
        self.image.resize(self.xy2[0] - (self.xy2[0] - 60), self.xy2[1] - (self.xy2[1] - 60))
        self.image.setPixmap(self.pixmap)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Example()
    ex.show()
    sys.exit(app.exec())